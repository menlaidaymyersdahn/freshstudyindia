# Myers Global Pathways — Android APK Build Kit

Package ID: com.myersglobalpathways.app
Default App URL: https://myersglobalpathways.com

## Option 1: Build an APK automatically on GitHub (no Android Studio needed)
1. Create a new GitHub repository and upload the extracted files from this ZIP.
2. Open the Actions tab and run "Build Myers Global Pathways Android APK".
3. Download MyersGlobalPathways-APK (app-debug.apk) from the completed workflow artifacts.

## Option 2: Build locally with Android Studio
1. Open this extracted folder in Android Studio.
2. Let Gradle sync complete.
3. Click Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. To point to your custom domain (https://myersglobalpathways.com), update START_URL in app/src/main/java/com/myersglobalpathways/app/MainActivity.java.
